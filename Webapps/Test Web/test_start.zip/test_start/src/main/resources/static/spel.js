/*
// haal dit uit commentaar als je de tip wil gebruiken

let eerste_kaart = null;
let tweede_kaart = null;
let dubbels_gevonden = 0;
let score = 0;  // verhoogt (+1) telkens dat een kaart wordt omgedraaid
 */
